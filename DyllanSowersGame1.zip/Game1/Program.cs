﻿// Dyllan Sowers

using System;

namespace Game1
{
    public class Program
    {
        public static void Main(string[] args)
        {
            GameScene1 aScene1 = new GameScene1();

            Console.ReadLine();
        }
    }
}
